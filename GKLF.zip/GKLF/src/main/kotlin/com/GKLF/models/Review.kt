package com.GKLF.models

import kotlinx.serialization.Serializable

@Serializable
data class Review(
    val reviewID:Int,
    val text:String,
    val rating:Double,
    val userID:Int,
    val elementID:Int
)