package com.GKLF.models

import kotlinx.serialization.Serializable

@Serializable
data class User(
    val userID:Int,
    val login:String,
    val password:String,
    val email:String,
    val name:String
)