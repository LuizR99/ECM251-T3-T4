package com.GKLF.models

import kotlinx.serialization.Serializable

@Serializable
data class Element(
    val elementID:Int,
    val name:String,
    val year:Int,
    val category:String,
    val duration:Int,
    val director:String,
    val type:String,
    val synopsis:String
)