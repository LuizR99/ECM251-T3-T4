package com.GKLF.shared

class SharedPaths {
    companion object{
        val urlDB = "jdbc:mysql://192.168.56.108/gklf"
    }
}