package com.GKLF.routes


import com.GKLF.dao.ReviewDAO
import com.GKLF.models.Review
import io.ktor.application.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*


fun Application.registerReviewRoutes() {
    routing {
        reviewRouting()
    }
}

fun Route.reviewRouting() {
    route("/review") {
        val review = ReviewDAO()
        val reviews = review.getAll()
        get {
            if (reviews.isNotEmpty()) {
                call.respond(reviews)
            } else {
                call.respondText("Sem reviews", status = HttpStatusCode.NotFound)
            }
        }
        get("{reviewID}") {
            val id = call.parameters["reviewID"] ?: return@get call.respondText(
                "Missing or malformed id",
                status = HttpStatusCode.BadRequest
            )

            reviews.find { review.getId(id.toInt()) } ?: return@get call.respondText(
                "No review with id $id",
                status = HttpStatusCode.NotFound
            )
            call.respond(review.getOne(id.toInt()))
        }
        // ATENÇÃO: POST precisa do reviewID mas não importa seu valor já que está com auto incremento!!!
        post {
            val rev = call.receive<Review>()
            review.setOne(rev)
            call.respondText("Review stored correctly", status = HttpStatusCode.Created)
        }

        delete("{reviewID}") {
            val id = call.parameters["reviewID"] ?: return@delete call.respond(HttpStatusCode.BadRequest)
            if (review.getId(id.toInt())) {
                review.delete(id.toInt())
                call.respondText("review removed correctly", status = HttpStatusCode.Accepted)
            } else {
                call.respondText("Not Found", status = HttpStatusCode.NotFound)
            }
        }

    }
}
