package com.GKLF.routes

import com.GKLF.dao.ElementDAO
import com.GKLF.models.Element
import io.ktor.routing.*
import io.ktor.application.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*


fun Application.registerElementRoutes() {
    routing {
        elementRouting()
    }
}

fun Route.elementRouting() {
    route("/element") {
        val element = ElementDAO()
        val elements = element.getAll()
        get {
            if (elements.isNotEmpty()) {
                call.respond(elements)
            } else {
                call.respondText("Sem elementos", status = HttpStatusCode.NotFound)
            }
        }
        get("{elementID}") {
            val id = call.parameters["elementID"] ?: return@get call.respondText(
                "Missing or malformed id",
                status = HttpStatusCode.BadRequest
            )

                elements.find { element.getId(id.toInt()) } ?: return@get call.respondText(
                    "No element with id $id",
                    status = HttpStatusCode.NotFound
                )
            call.respond(element.getOne(id.toInt()))
        }
        // ATENÇÃO: POST precisa do elementID mas não importa seu valor já que está com auto incremento!!!
        post {
            val elemento = call.receive<Element>()
            element.setOne(elemento)
            call.respondText("Element stored correctly", status = HttpStatusCode.Created)
        }

        delete("{elementID}") {
            val id = call.parameters["elementID"] ?: return@delete call.respond(HttpStatusCode.BadRequest)
            if (element.getId(id.toInt())) {
                element.delete(id.toInt())
                call.respondText("Element removed correctly", status = HttpStatusCode.Accepted)
            } else {
                call.respondText("Not Found", status = HttpStatusCode.NotFound)
            }
        }

    }
}
