package com.GKLF.routes

import com.GKLF.dao.UserDAO
import com.GKLF.models.User
import io.ktor.application.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*


fun Application.registerUserRoutes() {
    routing {
        userRouting()
    }
}

fun Route.userRouting() {
    route("/user") {
        val user = UserDAO()
        val users = user.getAll()
        get {
            if (users.isNotEmpty()) {
                call.respond(users)
            } else {
                call.respondText("Sem usuarios", status = HttpStatusCode.NotFound)
            }
        }
        get("{userID}") {
            val id = call.parameters["userID"] ?: return@get call.respondText(
                "Missing or malformed id",
                status = HttpStatusCode.BadRequest
            )

            users.find { user.getId(id.toInt()) } ?: return@get call.respondText(
                "No user with id $id",
                status = HttpStatusCode.NotFound
            )
            call.respond(user.getOne(id.toInt()))
        }
        // ATENÇÃO: POST precisa do userID mas não importa seu valor já que está com auto incremento!!!
        post {
            val usuario = call.receive<User>()
            user.setOne(usuario)
            call.respondText("User stored correctly", status = HttpStatusCode.Created)
        }

        delete("{userID}") {
            val id = call.parameters["userID"] ?: return@delete call.respond(HttpStatusCode.BadRequest)
            if (user.getId(id.toInt())) {
                user.delete(id.toInt())
                call.respondText("User removed correctly", status = HttpStatusCode.Accepted)
            } else {
                call.respondText("Not Found", status = HttpStatusCode.NotFound)
            }
        }

    }
}
