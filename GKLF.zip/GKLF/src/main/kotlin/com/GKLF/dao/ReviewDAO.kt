package com.GKLF.dao

import com.GKLF.models.Review

class ReviewDAO : GenericDAO {
    override fun getOne(id: Int): Any {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM Review WHERE reviewID = ${id};")
        var review : Review? = null
        while (resultSet?.next()!!){
            review = Review(
                resultSet.getInt("reviewID"),
                resultSet.getString("text"),
                resultSet.getDouble("rating"),
                resultSet.getInt("userID"),
                resultSet.getInt("elementID")
            )
        }
        connection.close()
        return review!!
    }

    override fun getId(id: Int): Boolean {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM Review WHERE reviewID = ${id};")
        var test = false
        if(resultSet?.next()!!)
            test = true

        connection.close()
        return test
    }

    override fun getAll(): List<Any> {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM Review;")
        val reviews = mutableListOf<Review>()
        while (resultSet?.next()!!){
            reviews.add(
                Review(
                resultSet.getInt("reviewID"),
                resultSet.getString("text"),
                resultSet.getDouble("rating"),
                resultSet.getInt("userID"),
                resultSet.getInt("elementID")
            )
            )
        }
        connection.close()
        return reviews!!
    }

    override fun setOne(obj: Any) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            INSERT INTO Review
            (text, rating, userID, elementID) 
            VALUES (?,?,?,?);
            """.trimMargin())
        val review = obj as Review
        preparedStatement?.setString(1,review.text)
        preparedStatement?.setDouble(2,review.rating)
        preparedStatement?.setInt(3,review.userID)
        preparedStatement?.setInt(4,review.elementID)
        preparedStatement?.executeUpdate()

        connection.close()
    }

    override fun setVar(list: List<Any>) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            INSERT INTO Review
            (text, rating, userID, elementID) 
            VALUES (?,?,?,?);
            """.trimMargin())
        for (obj in list) {
            val review = obj as Review
            preparedStatement?.setString(1, review.text)
            preparedStatement?.setDouble(2, review.rating)
            preparedStatement?.setInt(3, review.userID)
            preparedStatement?.setInt(4, review.elementID)
            preparedStatement?.executeUpdate()
        }
        connection.close()
    }

    override fun update(obj: Any) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            UPDATE Review
            SET text = ?, rating = ?, userID = ?, elementID = ?
            WHERE reviewID = ?;
            """.trimMargin())
        val review = obj as Review
        preparedStatement?.setString(1, review.text)
        preparedStatement?.setDouble(2, review.rating)
        preparedStatement?.setInt(3, review.userID)
        preparedStatement?.setInt(4, review.elementID)
        preparedStatement?.setInt(5, review.reviewID)
        preparedStatement?.executeUpdate()

        connection.close()
    }

    override fun delete(id: Int) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            DELETE FROM Review
            WHERE reviewID = ?;
            """.trimMargin())
        preparedStatement?.setInt(1, id)
        preparedStatement?.executeUpdate()

        connection.close()
    }
}