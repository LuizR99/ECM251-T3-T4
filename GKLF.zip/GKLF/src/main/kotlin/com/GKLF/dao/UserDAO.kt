package com.GKLF.dao

import com.GKLF.models.User

class UserDAO : GenericDAO {
    override fun getOne(id: Int): Any {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM User WHERE userID = ${id};")
        var user : User? = null
        while (resultSet?.next()!!){
            user = User(
                resultSet.getInt("userID"),
                resultSet.getString("login"),
                resultSet.getString("password"),
                resultSet.getString("email"),
                resultSet.getString("name")
            )
        }
        connection.close()
        return user!!
    }

    override fun getId(id: Int): Boolean {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM User WHERE userID = ${id};")
        var test = false
        if(resultSet?.next()!!)
            test = true

        connection.close()
        return test
    }

    override fun getAll(): List<Any> {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM User;")
        val users = mutableListOf<User>()
        while (resultSet?.next()!!){
            users.add(
                User(
                resultSet.getInt("userID"),
                resultSet.getString("login"),
                resultSet.getString("password"),
                resultSet.getString("email"),
                resultSet.getString("name")
            )
            )
        }
        connection.close()
        return users!!
    }

    override fun setOne(obj: Any) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            INSERT INTO User
            (login, password, email, name) 
            VALUES (?,?,?,?);
            """.trimMargin())
        val user = obj as User
        preparedStatement?.setString(1,user.login)
        preparedStatement?.setString(2,user.password)
        preparedStatement?.setString(3,user.email)
        preparedStatement?.setString(4,user.name)
        preparedStatement?.executeUpdate()

        connection.close()
    }

    override fun setVar(list: List<Any>) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            INSERT INTO User
            (login, password, email, name) 
            VALUES (?,?,?,?);
            """.trimMargin())
        for (obj in list) {
            val user = obj as User
            preparedStatement?.setString(1,user.login)
            preparedStatement?.setString(2,user.password)
            preparedStatement?.setString(3,user.email)
            preparedStatement?.setString(4,user.name)
            preparedStatement?.executeUpdate()
        }
        connection.close()
    }

    override fun update(obj: Any) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            UPDATE User
            SET login = ?, password = ?, email = ?, name = ?
            WHERE userID = ?;
            """.trimMargin())
        val user = obj as User
        preparedStatement?.setString(1,user.login)
        preparedStatement?.setString(2,user.password)
        preparedStatement?.setString(3,user.email)
        preparedStatement?.setString(4,user.name)
        preparedStatement?.setInt(5, user.userID)
        preparedStatement?.executeUpdate()

        connection.close()
    }

    override fun delete(id: Int) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            DELETE FROM User
            WHERE userID = ?;
            """.trimMargin())
        preparedStatement?.setInt(1, id)
        preparedStatement?.executeUpdate()

        connection.close()
    }
}