package com.GKLF.dao

import com.GKLF.models.Element
import kotlinx.serialization.Serializable

@Serializable

class ElementDAO : GenericDAO {
    override fun getOne(id: Int): Any {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM Element WHERE elementID = ${id};")
        var element : Element? = null
        while (resultSet?.next()!!){
            element = Element(
                resultSet.getInt("elementID"),
                resultSet.getString("name"),
                resultSet.getInt("year"),
                resultSet.getString("category"),
                resultSet.getInt("duration"),
                resultSet.getString("director"),
                resultSet.getString("type"),
                resultSet.getString("synopsis")
            )
        }
        connection.close()
        return element!!
    }

    override fun getId(id: Int): Boolean {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM Element WHERE elementID = ${id};")
        var test = false
        if(resultSet?.next()!!)
            test = true

        connection.close()
        return test
    }

    override fun getAll(): List<Any> {
        val connection = ConnectionDAO()
        val resultSet = connection.executeQuery("SELECT * FROM Element;")
        val elements = mutableListOf<Element>()
        while (resultSet?.next()!!){
            elements.add(
                Element(
                resultSet.getInt("elementID"),
                resultSet.getString("name"),
                resultSet.getInt("year"),
                resultSet.getString("category"),
                resultSet.getInt("duration"),
                resultSet.getString("director"),
                resultSet.getString("type"),
                resultSet.getString("synopsis")
            )
            )
        }
        connection.close()
        return elements!!
    }

    override fun setOne(obj: Any) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            INSERT INTO Element
            (name, year, category, duration, director, type, synopsis) 
            VALUES (?,?,?,?,?,?,?,?);
            """.trimMargin())
        val element = obj as Element
        preparedStatement?.setString(1,element.name)
        preparedStatement?.setInt(2,element.year)
        preparedStatement?.setString(3,element.category)
        preparedStatement?.setInt(4,element.duration)
        preparedStatement?.setString(5,element.director)
        preparedStatement?.setString(6,element.type)
        preparedStatement?.setString(7,element.synopsis)
        preparedStatement?.executeUpdate()
        connection.close()
    }

    override fun setVar(list: List<Any>) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            INSERT INTO Element
            (name, year, category, duration, director, type, synopsis) 
            VALUES (?,?,?,?,?,?,?,?);
            """.trimMargin())
        for (obj in list) {
            val element = obj as Element
            preparedStatement?.setString(1, element.name)
            preparedStatement?.setInt(2, element.year)
            preparedStatement?.setString(3, element.category)
            preparedStatement?.setInt(4, element.duration)
            preparedStatement?.setString(5, element.director)
            preparedStatement?.setString(6, element.type)
            preparedStatement?.setString(7,element.synopsis)
            preparedStatement?.executeUpdate()
        }
        connection.close()
    }

    override fun update(obj: Any) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            UPDATE Element
            SET name = ?, year = ?, category = ?, duration = ?, director = ?, type = ?, synopsis = ?
            WHERE elementID = ?;
            """.trimMargin())
        val element = obj as Element
        preparedStatement?.setString(1, element.name)
        preparedStatement?.setInt(2, element.year)
        preparedStatement?.setString(3, element.category)
        preparedStatement?.setInt(4, element.duration)
        preparedStatement?.setString(5, element.director)
        preparedStatement?.setString(6, element.type)
        preparedStatement?.setString(7,element.synopsis)
        preparedStatement?.setInt(8, element.elementID)

        preparedStatement?.executeUpdate()

        connection.close()
    }

    override fun delete(id: Int) {
        val connection = ConnectionDAO()
        val preparedStatement = connection.getPreparedStatement("""
            DELETE FROM Element
            WHERE elementID = ?;
            """.trimMargin())
        preparedStatement?.setInt(1, id)
        preparedStatement?.executeUpdate()

        connection.close()
    }
}