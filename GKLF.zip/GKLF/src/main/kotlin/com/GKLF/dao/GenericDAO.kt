package com.GKLF.dao

interface GenericDAO {
    fun getOne(id:Int): Any;
    fun getId(id:Int): Boolean;
    fun getAll() : List<Any>;
    fun setOne(obj : Any) : Unit;
    fun setVar(list : List<Any>) : Unit;
    fun update(obj : Any) : Unit;
    fun delete(id : Int) : Unit;
}