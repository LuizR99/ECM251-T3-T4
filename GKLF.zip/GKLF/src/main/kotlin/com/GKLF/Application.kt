package com.GKLF

import com.GKLF.routes.registerElementRoutes
import com.GKLF.routes.registerReviewRoutes
import com.GKLF.routes.registerUserRoutes
import io.ktor.application.Application
import io.ktor.application.*
import io.ktor.features.*
import io.ktor.serialization.*


fun main(args: Array<String>): Unit = io.ktor.server.netty.EngineMain.main(args)

fun Application.module() {
    install(CORS){
        host("0.0.0.0:8080")
        anyHost()
    }
    install(ContentNegotiation) {
        json()
    }
    registerElementRoutes()
    registerUserRoutes()
    registerReviewRoutes()

}




